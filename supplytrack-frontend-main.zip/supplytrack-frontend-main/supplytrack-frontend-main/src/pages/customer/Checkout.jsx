import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import AlertMessage from '../../components/AlertMessage';
import { useCart } from '../../context/CartContext';
import { adminService } from '../../services/adminService';
import { orderService } from '../../services/orderService';
import { formatCurrency } from '../../utils/formatCurrency';

const Checkout = () => {
  const { items, total, loadCart } = useCart();
  const navigate = useNavigate();
  const [stations, setStations] = useState([]);
  const [form, setForm] = useState({ pickup_station_id: '', customer_notes: '' });
  const [error, setError] = useState('');

  useEffect(() => {
    adminService.activePickupStations().then((response) => setStations(response.data)).catch(() => setStations([]));
  }, []);

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError('');
    try {
      const response = await orderService.placeOrder(form);
      await loadCart();
      navigate(`/customer/orders/${response.data.orders[0].id}`);
    } catch (err) {
      setError(err.response?.data?.message || 'Could not place order');
    }
  };

  return (
    <form className="panel p-4" onSubmit={handleSubmit}>
      <h1 className="h3 mb-3">Checkout</h1>
      <AlertMessage type="danger" message={error} onClose={() => setError('')} />
      <p className="text-muted">{items.length} cart items, total {formatCurrency(total)}</p>
      <div className="mb-3">
        <label className="form-label">Pickup station</label>
        <select className="form-select" value={form.pickup_station_id} onChange={(e) => setForm({ ...form, pickup_station_id: e.target.value })} required>
          <option value="">Choose station</option>
          {stations.map((station) => <option key={station.id} value={station.id}>{station.station_name} - {station.district}</option>)}
        </select>
        {stations.length === 0 && <div className="form-text">If no stations load, ask an admin to create stations or use seeded admin data.</div>}
      </div>
      <div className="mb-3">
        <label className="form-label">Customer notes</label>
        <textarea className="form-control" rows="3" value={form.customer_notes} onChange={(e) => setForm({ ...form, customer_notes: e.target.value })} />
      </div>
      <button className="btn btn-brand" type="submit" disabled={items.length === 0}>Place Order</button>
    </form>
  );
};

export default Checkout;
