import { Link } from 'react-router-dom';

const Home = () => (
  <section className="row align-items-center g-4">
    <div className="col-lg-6">
      <p className="text-brand fw-semibold mb-2">Ordering and pickup tracking</p>
      <h1 className="display-5 fw-bold">SupplyTrack</h1>
      <p className="lead">
        Browse supplies, place orders, let suppliers process them, and follow each package through pickup stations until delivery is complete.
      </p>
      <div className="d-flex flex-wrap gap-2">
        <Link className="btn btn-brand" to="/items">Browse Items</Link>
        <Link className="btn btn-outline-secondary" to="/register">Create Account</Link>
      </div>
    </div>
    <div className="col-lg-6">
      <div className="panel p-4">
        <div className="row g-3">
          {['Pending', 'Packed', 'In Transit', 'Ready for Pickup'].map((step, index) => (
            <div className="col-6" key={step}>
              <div className="stat-card p-3 h-100">
                <span className="badge text-bg-success mb-2">{index + 1}</span>
                <h2 className="h6">{step}</h2>
                <p className="small text-muted mb-0">Each update is recorded in the tracking history.</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  </section>
);

export default Home;
